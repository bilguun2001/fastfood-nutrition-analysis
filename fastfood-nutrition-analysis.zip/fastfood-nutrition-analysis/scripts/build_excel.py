import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.chart import BarChart, Reference
from openpyxl.utils import get_column_letter

FONT = "Arial"
NAVY = "1F4E78"
INK = "1A1A1A"
HEADER_FILL = PatternFill("solid", fgColor=NAVY)
HEADER_FONT = Font(name=FONT, bold=True, color="FFFFFF", size=10.5)
TITLE_FONT = Font(name=FONT, bold=True, size=14, color=NAVY)
SUB_FONT = Font(name=FONT, italic=True, size=9.5, color="666666")
BODY_FONT = Font(name=FONT, size=10.5)
THIN = Side(style="thin", color="D9D9D9")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

df = pd.read_csv("data/fastfood_calories.csv")
RESTAURANTS = sorted(df["restaurant"].unique().tolist())

wb = Workbook()

# ============================================================
# Sheet 1: Raw Data
# ============================================================
ws = wb.active
ws.title = "Raw Data"

cols = list(df.columns)
ws.append(cols)
for r in df.itertuples(index=False):
    ws.append(list(r))

n_rows = len(df) + 1  # incl header
last_col = get_column_letter(len(cols))

for c in range(1, len(cols) + 1):
    cell = ws.cell(row=1, column=c)
    cell.font = HEADER_FONT
    cell.fill = HEADER_FILL
    cell.alignment = Alignment(horizontal="center", vertical="center")

for row in ws.iter_rows(min_row=2, max_row=n_rows, min_col=1, max_col=len(cols)):
    for cell in row:
        cell.font = BODY_FONT

# Helper column: sodium rank (used by the Top Sodium Items sheet for INDEX/MATCH lookups)
rank_col = len(cols) + 1
rank_letter = get_column_letter(rank_col)
ws.cell(row=1, column=rank_col, value="SodiumRank").font = HEADER_FONT
ws.cell(row=1, column=rank_col).fill = HEADER_FILL
sodium_letter = get_column_letter(cols.index("sodium") + 1)
for r in range(2, n_rows + 1):
    ws.cell(row=r, column=rank_col,
             value=f"=RANK({sodium_letter}{r},${sodium_letter}$2:${sodium_letter}${n_rows},0)").font = BODY_FONT

tbl = Table(displayName="RawData", ref=f"A1:{rank_letter}{n_rows}")
tbl.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
ws.add_table(tbl)

widths = {"A": 13, "B": 34, "C": 9, "I": 9, "M": 9, "Q": 8, rank_letter: 11}
for col_letter, w in widths.items():
    ws.column_dimensions[col_letter].width = w
ws.freeze_panes = "A2"

restaurant_letter = "A"
calories_letter = get_column_letter(cols.index("calories") + 1)
protein_letter = get_column_letter(cols.index("protein") + 1)
item_letter = "B"

# ============================================================
# Sheet 2: Restaurant Summary (formula-driven — AVERAGEIF / COUNTIFS)
# ============================================================
ws2 = wb.create_sheet("Restaurant Summary")
ws2["A1"] = "Fast Food Nutrition — Restaurant Summary"
ws2["A1"].font = TITLE_FONT
ws2["A2"] = "All figures calculated live from the Raw Data tab using AVERAGEIF / COUNTIFS — edit Raw Data and these update automatically."
ws2["A2"].font = SUB_FONT
ws2.merge_cells("A1:I1")
ws2.merge_cells("A2:I2")

headers = ["Restaurant", "Menu Items", "Avg Calories", "Avg Protein (g)",
           "Protein per 100 cal", "Avg Sodium (mg)", "% of Daily Sodium Limit (2,300mg)",
           "Items > 800 cal", "% of Menu > 800 cal"]
hr = 4
for c, h in enumerate(headers, start=1):
    cell = ws2.cell(row=hr, column=c, value=h)
    cell.font = HEADER_FONT
    cell.fill = HEADER_FILL
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.border = BORDER

start = hr + 1
for i, rest in enumerate(RESTAURANTS):
    r = start + i
    ws2.cell(row=r, column=1, value=rest).font = Font(name=FONT, size=10.5, color="0000FF")
    ws2.cell(row=r, column=2,
              value=f'=COUNTIF(\'Raw Data\'!{restaurant_letter}:{restaurant_letter},A{r})')
    ws2.cell(row=r, column=3,
              value=f'=ROUND(AVERAGEIF(\'Raw Data\'!{restaurant_letter}:{restaurant_letter},A{r},\'Raw Data\'!{calories_letter}:{calories_letter}),0)')
    ws2.cell(row=r, column=4,
              value=f'=ROUND(AVERAGEIF(\'Raw Data\'!{restaurant_letter}:{restaurant_letter},A{r},\'Raw Data\'!{protein_letter}:{protein_letter}),1)')
    ws2.cell(row=r, column=5, value=f'=ROUND(D{r}/C{r}*100,2)')
    ws2.cell(row=r, column=6,
              value=f'=ROUND(AVERAGEIF(\'Raw Data\'!{restaurant_letter}:{restaurant_letter},A{r},\'Raw Data\'!{sodium_letter}:{sodium_letter}),0)')
    ws2.cell(row=r, column=7, value=f'=F{r}/2300')
    ws2.cell(row=r, column=7).number_format = "0.0%"
    ws2.cell(row=r, column=8,
              value=(f'=COUNTIFS(\'Raw Data\'!{restaurant_letter}:{restaurant_letter},A{r},'
                      f'\'Raw Data\'!{calories_letter}:{calories_letter},">800")'))
    ws2.cell(row=r, column=9, value=f'=H{r}/B{r}')
    ws2.cell(row=r, column=9).number_format = "0.0%"
    for c in range(1, 10):
        cell = ws2.cell(row=r, column=c)
        cell.border = BORDER
        if c != 1:
            cell.font = BODY_FONT
            cell.alignment = Alignment(horizontal="center")

end = start + len(RESTAURANTS) - 1

# Overall totals row
tot_r = end + 1
ws2.cell(row=tot_r, column=1, value="All Restaurants").font = Font(name=FONT, bold=True, size=10.5)
ws2.cell(row=tot_r, column=2, value=f"=SUM(B{start}:B{end})")
ws2.cell(row=tot_r, column=3, value=f"=ROUND(AVERAGE('Raw Data'!{calories_letter}2:{calories_letter}{n_rows}),0)")
ws2.cell(row=tot_r, column=4, value=f"=ROUND(AVERAGE('Raw Data'!{protein_letter}2:{protein_letter}{n_rows}),1)")
ws2.cell(row=tot_r, column=5, value=f"=ROUND(D{tot_r}/C{tot_r}*100,2)")
ws2.cell(row=tot_r, column=6, value=f"=ROUND(AVERAGE('Raw Data'!{sodium_letter}2:{sodium_letter}{n_rows}),0)")
ws2.cell(row=tot_r, column=7, value=f"=F{tot_r}/2300")
ws2.cell(row=tot_r, column=7).number_format = "0.0%"
ws2.cell(row=tot_r, column=8, value=f'=COUNTIFS(\'Raw Data\'!{calories_letter}:{calories_letter},">800")')
ws2.cell(row=tot_r, column=9, value=f"=H{tot_r}/B{tot_r}")
ws2.cell(row=tot_r, column=9).number_format = "0.0%"
for c in range(1, 10):
    cell = ws2.cell(row=tot_r, column=c)
    cell.font = Font(name=FONT, bold=True, size=10.5)
    cell.border = BORDER
    if c != 1:
        cell.alignment = Alignment(horizontal="center")

for col_letter, w in {"A": 15, "B": 11, "C": 12, "D": 14, "E": 16, "F": 14, "G": 20, "H": 13, "I": 18}.items():
    ws2.column_dimensions[col_letter].width = w

note_r = tot_r + 2
ws2.cell(row=note_r, column=1,
          value="Source: R for Data Science TidyTuesday (2018-09-04), compiled from each chain's published nutrition facts. Daily sodium limit per FDA guidance (2,300mg).").font = SUB_FONT
ws2.merge_cells(f"A{note_r}:I{note_r}")

# --- Native Excel charts, built from the formulas above ---
chart1 = BarChart()
chart1.type = "bar"
chart1.title = "Average Calories per Menu Item, by Restaurant"
chart1.y_axis.title = None
chart1.x_axis.title = "Calories"
chart1.height, chart1.width = 8, 16
data = Reference(ws2, min_col=3, min_row=hr, max_row=end)
cats = Reference(ws2, min_col=1, min_row=start, max_row=end)
chart1.add_data(data, titles_from_data=True)
chart1.set_categories(cats)
chart1.legend = None
ws2.add_chart(chart1, f"A{note_r + 2}")

chart2 = BarChart()
chart2.type = "bar"
chart2.title = "Protein per 100 Calories, by Restaurant"
chart2.x_axis.title = "Grams of protein per 100 cal"
chart2.height, chart2.width = 8, 16
data2 = Reference(ws2, min_col=5, min_row=hr, max_row=end)
chart2.add_data(data2, titles_from_data=True)
chart2.set_categories(cats)
chart2.legend = None
ws2.add_chart(chart2, f"A{note_r + 19}")

chart3 = BarChart()
chart3.type = "bar"
chart3.title = "Average Sodium (mg) per Menu Item, by Restaurant"
chart3.x_axis.title = "Sodium (mg)"
chart3.height, chart3.width = 8, 16
data3 = Reference(ws2, min_col=6, min_row=hr, max_row=end)
chart3.add_data(data3, titles_from_data=True)
chart3.set_categories(cats)
chart3.legend = None
ws2.add_chart(chart3, f"A{note_r + 36}")

# ============================================================
# Sheet 3: Top 10 Sodium Items (INDEX/MATCH lookup demo)
# ============================================================
ws3 = wb.create_sheet("Top Sodium Items")
ws3["A1"] = "Top 10 Highest-Sodium Menu Items"
ws3.merge_cells("A1:E1")
ws3["A1"].font = TITLE_FONT
ws3["A2"] = "Pulled from Raw Data with INDEX/MATCH against the SodiumRank helper column — no hardcoded values."
ws3.merge_cells("A2:E2")
ws3["A2"].font = SUB_FONT

headers3 = ["Rank", "Restaurant", "Item", "Calories", "Sodium (mg)", "% of Daily Sodium Limit"]
hr3 = 4
for c, h in enumerate(headers3, start=1):
    cell = ws3.cell(row=hr3, column=c, value=h)
    cell.font = HEADER_FONT
    cell.fill = HEADER_FILL
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.border = BORDER

for k in range(1, 11):
    r = hr3 + k
    ws3.cell(row=r, column=1, value=k)
    ws3.cell(row=r, column=2,
              value=f"=INDEX('Raw Data'!{restaurant_letter}:{restaurant_letter},MATCH(A{r},'Raw Data'!${rank_letter}:${rank_letter},0))")
    ws3.cell(row=r, column=3,
              value=f"=INDEX('Raw Data'!{item_letter}:{item_letter},MATCH(A{r},'Raw Data'!${rank_letter}:${rank_letter},0))")
    ws3.cell(row=r, column=4,
              value=f"=INDEX('Raw Data'!{calories_letter}:{calories_letter},MATCH(A{r},'Raw Data'!${rank_letter}:${rank_letter},0))")
    ws3.cell(row=r, column=5,
              value=f"=INDEX('Raw Data'!{sodium_letter}:{sodium_letter},MATCH(A{r},'Raw Data'!${rank_letter}:${rank_letter},0))")
    ws3.cell(row=r, column=6, value=f"=E{r}/2300")
    ws3.cell(row=r, column=6).number_format = "0%"
    for c in range(1, 7):
        cell = ws3.cell(row=r, column=c)
        cell.font = BODY_FONT
        cell.border = BORDER
        if c != 3:
            cell.alignment = Alignment(horizontal="center")

for col_letter, w in {"A": 7, "B": 15, "C": 40, "D": 11, "E": 13, "F": 18}.items():
    ws3.column_dimensions[col_letter].width = w

wb.save("excel/fastfood_nutrition_analysis.xlsx")
print("workbook written")
